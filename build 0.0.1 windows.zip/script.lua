local engine = require("BBE.engine")
local config = require("BBE.config")
local input = require("BBE.input")
local sound = require("BBE.utils")

local a = engine.sprite.NewSprite("icon.png")
local x = 0

sound.sound_load("music_1.wav", "background_music")
sound.sound_create_source("background_music", true, 0.2, 1.0)
sound.sound_play("background_music")

function update()
    if input.keys.W then
        x = x + 1
    end

    if input.keys.S then
        x = x - 1
    end

    engine.sprite.SetRotate(a, {x, x, x})
end