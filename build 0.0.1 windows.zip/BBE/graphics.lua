local graphics = {}

graphics.objects = {}

graphics.sprite = {}

function graphics.sprite.NewSprite(texture)
    table.insert(graphics.objects, {texture, {0, 0, -5}, {1, 1, 1}, {0, 0, 0}, {0, 0, 0}})
    return #graphics.objects
end

function graphics.sprite.SetPos(object, pos)
    graphics.objects[object][2] = pos
end

function graphics.sprite.SetScale(object, scale)
    graphics.objects[object][3] = scale
end

function graphics.sprite.SetRotate(object, rotate)
    graphics.objects[object][4] = rotate
end

function graphics.sprite.SetColor(object, color)
    graphics.objects[object][5] = color
end

return graphics