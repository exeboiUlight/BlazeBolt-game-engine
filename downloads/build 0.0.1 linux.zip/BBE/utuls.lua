local utils = {sound = {}}

function utils.quit()
    os.exit()
end

function utils.sound_load(filename, name)
    return sound_load(filename, name)
end

function utils.sound_play(name)
    sound_play(name)
end

function utils.sound_stop(name)
    sound_stop(name)
end

function utils.sound_set_volume(name, volume)
    sound_set_volume(name, volume)
end

function utils.sound_create_source(name, looping, volume, pitch)
    looping = looping or false
    volume = volume or 1.0
    pitch = pitch or 1.0
    return sound_create_source(name, looping, volume, pitch)
end

function utils.sound_is_playing(name)
    return sound_is_playing(name)
end

-- Дополнительные утилиты
function utils.print_table(t, indent)
    indent = indent or 0
    for k, v in pairs(t) do
        local formatting = string.rep("  ", indent) .. k .. ": "
        if type(v) == "table" then
            print(formatting)
            utils.print_table(v, indent + 1)
        else
            print(formatting .. tostring(v))
        end
    end
end

function utils.vector3(x, y, z)
    return {x or 0, y or 0, z or 0}
end

function utils.distance(vec1, vec2)
    local dx = vec2[1] - vec1[1]
    local dy = vec2[2] - vec1[2]
    local dz = vec2[3] - vec1[3]
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

function utils.lerp(a, b, t)
    return a + (b - a) * math.max(0, math.min(1, t))
end

function utils.clamp(value, min, max)
    return math.max(min, math.min(max, value))
end

-- Функции для работы со временем
utils.time = {
    delta_time = 0,
    total_time = 0,
    frame_count = 0
}

function utils.time.update(dt)
    utils.time.delta_time = dt
    utils.time.total_time = utils.time.total_time + dt
    utils.time.frame_count = utils.time.frame_count + 1
end

function utils.time.get_delta_time()
    return utils.time.delta_time
end

function utils.time.get_total_time()
    return utils.time.total_time
end

function utils.time.get_frame_count()
    return utils.time.frame_count
end

-- Функции для работы с файлами
function utils.file_exists(filename)
    local file = io.open(filename, "r")
    if file then
        file:close()
        return true
    end
    return false
end

function utils.read_file(filename)
    local file = io.open(filename, "r")
    if file then
        local content = file:read("*a")
        file:close()
        return content
    end
    return nil
end

function utils.write_file(filename, content)
    local file = io.open(filename, "w")
    if file then
        file:write(content)
        file:close()
        return true
    end
    return false
end

return utils