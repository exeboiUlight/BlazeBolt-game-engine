local window = {
    width = 1200,
    height = 600,
    title = "Game in Blaze Bolt Engine",
    icon = "icon.png",
    background = {100, 100, 100}
}

function window.SetSize(width, height)
    window.width = width
    window.height = height
end

function window.SetTitle(title)
    window.title = title
end

function window.SetIcon(icon)
    window.icon = icon
end

function window.SetBackground(rgb)
    window.background = rgb
end

return window