local scene = {}

function scene.LoadScene(filename)
    local file = io.open(filename, "rb")
    if not file then
        error("Не удалось открыть файл сцены: " .. filename)
    end
    
    local content = file:read("*a")
    file:close()
    
    local bytes = {}
    for i = 1, #content do
        bytes[i] = content:byte(i)
    end
    
    local function bytesToNumber(offset, byteLength)
        if byteLength == 4 then
            local sign = bytes[offset] & 0x80 > 0 and -1 or 1
            local exponent = ((bytes[offset] & 0x7F) << 1) | (bytes[offset + 1] >> 7)
            local mantissa = ((bytes[offset + 1] & 0x7F) << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3]
            
            if exponent == 0 and mantissa == 0 then
                return 0.0
            elseif exponent == 0xFF then
                return mantissa == 0 and sign * math.huge or 0.0/0.0
            end
            
            exponent = exponent - 127
            mantissa = mantissa / (2^23) + 1
            
            return sign * mantissa * (2^exponent)
        elseif byteLength == 2 then
            return (bytes[offset] << 8) | bytes[offset + 1]
        end
        return 0
    end
    
    local function bytesToString(offset, length)
        local chars = {}
        for i = 0, length - 1 do
            table.insert(chars, string.char(bytes[offset + i]))
        end
        return table.concat(chars)
    end
    
    local offset = 1
    local totalObjects = bytesToNumber(offset, 2)
    offset = offset + 2
    
    local objects = {}
    
    for i = 1, totalObjects do
        local nameLength = bytesToNumber(offset, 2)
        offset = offset + 2
        
        local name = bytesToString(offset, nameLength)
        offset = offset + nameLength
        
        local object = {
            name = name,
            position = {
                x = bytesToNumber(offset, 4),
                y = bytesToNumber(offset + 4, 4),
                z = bytesToNumber(offset + 8, 4)
            },
            scale = {
                x = bytesToNumber(offset + 12, 4),
                y = bytesToNumber(offset + 16, 4),
                z = bytesToNumber(offset + 20, 4)
            },
            rotation = {
                x = bytesToNumber(offset + 24, 4),
                y = bytesToNumber(offset + 28, 4),
                z = bytesToNumber(offset + 32, 4)
            }
        }
        
        offset = offset + 36
        table.insert(objects, object)
    end
    
    return {
        totalObjects = totalObjects,
        objects = objects,
        bytesRead = offset - 1,
        totalBytes = #bytes
    }
end

return scene