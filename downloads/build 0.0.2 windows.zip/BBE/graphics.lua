local graphics = {}

-- sprite

graphics.objects = {}

graphics.sprite = {}

function graphics.sprite.NewTexture(path)
    return NewTexture(path)
end

function graphics.sprite.NewSprite(texture)
    table.insert(graphics.objects, {texture, {0, 0, -5}, {1, 1, 1}, {0, 0, 0}, {0, 0, 0}})
    return #graphics.objects
end

function graphics.sprite.SetPos(object, pos)
    graphics.objects[object][2] = pos
end

function graphics.sprite.SetScale(object, scale)
    graphics.objects[object][3] = scale
end

function graphics.sprite.SetRotate(object, rotate)
    graphics.objects[object][4] = rotate
end

function graphics.sprite.SetColor(object, color)
    graphics.objects[object][5] = color
end

-- Camera

graphics.camera = {pos={0, 0, 0}, rotate={0, 0, 0}}

function graphics.camera.SetPos(x, y, z)
    graphics.camera.pos = {x, y, z}
end

function graphics.camera.SetRotate(x, y, z)
    graphics.camera.rotate = {x, y ,z}
end

function graphics.camera.Move(x, y, z)
    graphics.camera.pos[1] = graphics.camera.pos[1] + x
    graphics.camera.pos[2] = graphics.camera.pos[2] + y
    graphics.camera.pos[3] = graphics.camera.pos[3] + z
end

function graphics.camera.Rotate(x, y, z)
    graphics.camera.rotate[1] = graphics.camera.rotate[1] + x
    graphics.camera.rotate[2] = graphics.camera.rotate[2] + y
    graphics.camera.rotate[3] = graphics.camera.rotate[3] + z
end

return graphics