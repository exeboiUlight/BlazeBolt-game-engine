-- BBE.phisics - its custom phisics engine for BlazeBolt game engine
local input = require("BBE.input")

local Phisics = {}

function Phisics.Create()
    
end

return Phisics