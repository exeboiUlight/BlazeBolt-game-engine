local graphics = require("BBE.graphics")
local config = require("BBE.config")
local input = require("BBE.input")
local utils = require("BBE.utils")

local icon_texture = graphics.sprite.NewTexture("icon.png")

local a = graphics.sprite.NewSprite(icon_texture)
graphics.sprite.SetScale(a, {1, 1, -5})

--print(icon_texture)

local text = graphics.text.create(" ")
graphics.text.set_pos(text, {102, 102})

local z = 0

local speed = 15

--utils.sound_load("music_1.wav", "background_music")
--utils.sound_create_source("background_music", true, 0.2, 1.0)
--utils.sound_play("background_music")

local lastTime = os.clock()
local fps = 0
local fpsTimer = 0.0

local b = graphics.model.Create("assets/model/map1.obj", "tex_test.png")

config.SetBackground({255, 191, 150})

function update()
    local time = os.clock()
    local deltaTime = time - lastTime
    lastTime = time

    fpsTimer = fpsTimer + deltaTime
    fps = fps + 1

    if fpsTimer >= 1.0 then
        -- print(string.format('FPS: %d', fps))
        graphics.text.destroy(text)
        local text = graphics.text.create(string.format('FPS: %d', fps))
        graphics.text.set_pos(text, {102, 102})
        fps = 0
    end
    fpsTimer = fpsTimer - math.floor(fpsTimer)

    if input.keys.W then
        z = z + speed * deltaTime
    end

    if input.keys.S then
        z = z - speed * deltaTime
    end

    graphics.sprite.SetRotate(a, {z, z, z})
end