local graphics = require("BBE.graphics")
local config = require("BBE.config")
local input = require("BBE.input")
local utils = require("BBE.utils")

local lastTime = os.clock()
local fps = 0
local fpsTimer = 0.0

config.SetBackground({255, 191, 150})

local player_texture = {
    graphics.sprite.NewTexture("assets/texture/player/1.png"),
    graphics.sprite.NewTexture("assets/textrue/player/2.png"),
    graphics.sprite.NewTexture("assets/texture/player/3.png"),
    graphics.sprite.NewTexture("assets/texture/player/4.png"),
    graphics.sprite.NewTexture("assets/texture/player/5.png"),
    graphics.sprite.NewTexture("assets/texture/player/6.png"),
    graphics.sprite.NewTexture("assets/texture/player/7.png")
}

local a = graphics.sprite.NewSprite(player_texture[1]);

graphics.sprite.SetScale(a, {0.4, 1, 1})

-- local b = garphics.model.Create("assets/model/cube.obj")

function update()
    local time = os.clock()
    local deltaTime = time - lastTime
    lastTime = time

    fpsTimer = fpsTimer + deltaTime
    fps = fps + 1

    if fpsTimer >= 1.0 then
        -- print(string.format('FPS: %d', fps))
        fps = 0
    end
    fpsTimer = fpsTimer - math.floor(fpsTimer)
end