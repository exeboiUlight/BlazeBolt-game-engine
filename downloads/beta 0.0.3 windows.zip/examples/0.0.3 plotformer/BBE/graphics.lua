local graphics = {}

-- Основные функции спрайтов
graphics.sprite = {}
graphics.text = {}
graphics.model = {}

function graphics.sprite.NewTexture(path)
    return NewTexture(path)
end

function graphics.sprite.NewSprite(texture)
    return CreateSprite(texture)
end

function graphics.sprite.SetPos(object, pos)
    return SetPos(object, pos)
end

function graphics.sprite.SetScale(object, scale)
    return SetScale(object, scale)
end

function graphics.sprite.SetRotate(object, rotate)
    return SetRotate(object, rotate)
end

function graphics.sprite.SetColor(object, rgba)
    return SetColorRGB(object, rgba)
end

function graphics.sprite.Delete(object)
    return DestroySprite(object)
end

function graphics.sprite.SetTexture(object, texture)
    SetTexture(object, texture)
end

-- text

function graphics.text.create(text)
    return NewText(text)
end

function graphics.text.set_pos(object, pos)
    return SetPositionText(object, pos)
end

function graphics.text.set_text(object, text)
    return SetScaleText(object, text)
end

function graphics.text.set_scale(object, scale)
    return SetScaleText(object, scale)
end

function graphics.text.set_color(object, rgb)
    return SetRGBText(object, rgb)
end

function graphics.text.destroy(object)
    return TextDestroy(object)
end

-- model 3D

function graphics.model.Create(model, texture)
    return LoadOBJModel(model, texture)
end

function graphics.model.SetPos(object, pos)
    return SetModelPosition(object, pos)
end

function graphics.model.SetScale(object, scale)
    return SetModelScale(object, scale)
end

function graphics.model.SetRotate(object, rotate)
    return SetModelRotation(object, rotate)
end

-- Система анимаций
graphics.animation = {
    animations = {},
    activeAnimations = {}
}

-- Создание новой анимации
function graphics.animation.create(name, config)
    graphics.animation.animations[name] = {
        frames = config.frames or {},
        delays = config.delays or {},
        loop = config.loop or true,
        currentFrame = 1,
        timer = 0,
        playing = false
    }
end

-- Запуск анимации
function graphics.animation.play(name, spriteObject)
    if graphics.animation.animations[name] then
        graphics.animation.activeAnimations[spriteObject] = {
            name = name,
            currentFrame = 1,
            timer = 0,
            playing = true
        }
        
        -- Установить первый кадр
        local anim = graphics.animation.animations[name]
        if anim.frames[1] then
            graphics.sprite.SetTexture(spriteObject, anim.frames[1])
        end
    end
end

-- Остановка анимации
function graphics.animation.stop(spriteObject)
    graphics.animation.activeAnimations[spriteObject] = nil
end

-- Пауза анимации
function graphics.animation.pause(spriteObject)
    if graphics.animation.activeAnimations[spriteObject] then
        graphics.animation.activeAnimations[spriteObject].playing = false
    end
end

-- Возобновление анимации
function graphics.animation.resume(spriteObject)
    if graphics.animation.activeAnimations[spriteObject] then
        graphics.animation.activeAnimations[spriteObject].playing = true
    end
end

-- Установка кадра анимации
function graphics.animation.setFrame(spriteObject, frame)
    local activeAnim = graphics.animation.activeAnimations[spriteObject]
    if activeAnim and graphics.animation.animations[activeAnim.name] then
        local anim = graphics.animation.animations[activeAnim.name]
        if frame >= 1 and frame <= #anim.frames then
            activeAnim.currentFrame = frame
            activeAnim.timer = 0
            graphics.sprite.SetTexture(spriteObject, anim.frames[frame])
        end
    end
end

-- Обновление всех анимаций (должен вызываться каждый кадр)
function graphics.animation.update(deltaTime)
    for spriteObject, activeAnim in pairs(graphics.animation.activeAnimations) do
        if activeAnim.playing then
            local anim = graphics.animation.animations[activeAnim.name]
            if anim then
                activeAnim.timer = activeAnim.timer + deltaTime
                
                local currentDelay = anim.delays[activeAnim.currentFrame] or 0.1
                
                if activeAnim.timer >= currentDelay then
                    activeAnim.timer = 0
                    activeAnim.currentFrame = activeAnim.currentFrame + 1
                    
                    if activeAnim.currentFrame > #anim.frames then
                        if anim.loop then
                            activeAnim.currentFrame = 1
                        else
                            graphics.animation.stop(spriteObject)
                            return
                        end
                    end
                    
                    -- Установить текстуру текущего кадра
                    graphics.sprite.SetTexture(spriteObject, anim.frames[activeAnim.currentFrame])
                end
            end
        end
    end
end

-- Получение информации об анимации
function graphics.animation.getInfo(spriteObject)
    local activeAnim = graphics.animation.activeAnimations[spriteObject]
    if activeAnim then
        return {
            name = activeAnim.name,
            currentFrame = activeAnim.currentFrame,
            totalFrames = #graphics.animation.animations[activeAnim.name].frames,
            playing = activeAnim.playing
        }
    end
    return nil
end

-- Удаление анимации
function graphics.animation.remove(name)
    graphics.animation.animations[name] = nil
    -- Удалить из активных анимаций
    for spriteObject, activeAnim in pairs(graphics.animation.activeAnimations) do
        if activeAnim.name == name then
            graphics.animation.activeAnimations[spriteObject] = nil
        end
    end
end

-- Camera
graphics.camera = {pos={0, 0, 0}, rotate={0, 0, 0}}

function graphics.camera.SetPos(x, y, z)
    graphics.camera.pos = {x, y, z}
end

function graphics.camera.SetRotate(x, y, z)
    graphics.camera.rotate = {x, y ,z}
end

function graphics.camera.Move(x, y, z)
    graphics.camera.pos[1] = graphics.camera.pos[1] + x
    graphics.camera.pos[2] = graphics.camera.pos[2] + y
    graphics.camera.pos[3] = graphics.camera.pos[3] + z
end

function graphics.camera.Rotate(x, y, z)
    graphics.camera.rotate[1] = graphics.camera.rotate[1] + x
    graphics.camera.rotate[2] = graphics.camera.rotate[2] + y
    graphics.camera.rotate[3] = graphics.camera.rotate[3] + z
end

return graphics