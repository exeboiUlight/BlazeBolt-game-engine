local graphics = require("BBE.graphics")
local config = require("BBE.config")
local input = require("BBE.input")
local utils = require("BBE.utils")
local scene = require("BBE.scene")

local icon_texture = graphics.sprite.NewTexture("icon.png")

-- local a = graphics.sprite.NewSprite(icon_texture)

print(icon_texture)

-- nvdia GeForce GTX 1070; intel core i7-2600 = (60 or 100) fps (its max fps)

-- local sprites = {}

--for i = 0, 100 do
--    for j = 0, 100 do
--        local b = graphics.sprite.NewSprite(icon_texture)
--        sprites[i + j * 100] = b
--
--        graphics.sprite.SetPos(b, {i, j, -5})
--    end
--end

local x = 0
local y = 0
local z = 0

local speed = 15

--sound.sound_load("music_1.wav", "background_music")
--sound.sound_create_source("background_music", true, 0.2, 1.0)
--sound.sound_play("background_music")

local lastTime = os.clock()
local fps = 0
local fpsTimer = 0.0

config.SetBackground({255, 191, 150})

function update()
    local time = os.clock()
    local deltaTime = time - lastTime
    lastTime = time

    fpsTimer = fpsTimer + deltaTime
    fps = fps + 1

    if fpsTimer >= 1.0 then
        print(string.format('FPS: %d', fps))
        fps = 0
    end
    fpsTimer = fpsTimer - math.floor(fpsTimer)

--     for i = 0, 100 do
--         for j = 0, 100 do
--             graphics.sprite.SetPos(sprites[i + j * 100], {i + math.sin(i * 0.43 + time), j + math.cos(j * 0.24 - time), -5})
--             graphics.sprite.SetRotate(sprites[i + j * 100], {0.0, 0.0, i * 45.0 + j * 36.0 + math.sin(time * 31.4)})
--         end
--     end

    if input.keys.W then
        z = z + speed * utils.time.get_delta_time()
    end

    if input.keys.S then
        z = z - speed * utils.time.get_delta_time()
    end

    if input.keys.D then
        x = x + speed * utils.time.get_delta_time()
    end

    if input.keys.A then
        x = x - speed * utils.time.get_delta_time()
    end

    if input.keys.E then
        y = y + speed * utils.time.get_delta_time()
    end

    if input.keys.Q then
        y = y - speed * utils.time.get_delta_time()
    end

    graphics.camera.SetPos(x, y, z)
end